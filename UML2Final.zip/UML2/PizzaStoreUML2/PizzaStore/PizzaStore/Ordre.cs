﻿
public class Ordre
{
    public static int nextId = 1;
    private int _ordreNR;
    pizza _pizzaItem;
    Customer _newCustomers;

    public Ordre()
    {
        Id = nextId++;
    }

    public Ordre (int ordreNR, pizza pizzaItem, Customer newCustomers)
    {
        Id = nextId++;
        _ordreNR = ordreNR;
        _pizzaItem = pizzaItem;
        _newCustomers = newCustomers;
    }
    public int ordreNR { get; set; }
    public int Id { get; set; }
    private double CalculateTotalPrice(double price)
    {
        return (price) * 1.25 + 40;
    }

    public override string ToString()
    {
        return $"{nameof(Id)}={Id.ToString()}, Pizzaen koster {_pizzaItem.Price}, " +
            $"navnet på pizzaen {_pizzaItem.NamePizza} , tak for din ordre {_newCustomers.Name}, " +
            $"din samlet pris med moms of kørsel er: {CalculateTotalPrice(_pizzaItem.Price)}";
    }
}
