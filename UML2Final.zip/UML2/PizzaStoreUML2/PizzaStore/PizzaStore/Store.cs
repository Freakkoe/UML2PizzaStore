﻿using PizzaStore;

namespace Pizzastore
{
    internal class Store
    {
        public void Start()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            #region Collection Of New New
            pizza pizza1 = new pizza("SalamiDream", 49);
            pizza pizza2 = new pizza("cheeseParadise", 59);
            pizza pizza3 = new pizza("Meatlover", 69);
            pizza pizza4 = new pizza("BigPizza", 79);
            Customer customer1 = new Customer("Jonas", "Jonas123@mail.dk", "23456789", "5100 Sjælby Solvej 2");
            Customer customer2 = new Customer("Karen", "karen123@live.dk", "13355779", "5000 Rockby Månevej 3");
            Customer customer3 = new Customer("Torben", "Torben321@cednet.dk", "98275619", "6700 Tårnby Skillevej 34");
            Customer customer4 = new Customer("Kirsten", "kirsten321@mail.dk", "75298753", "9845 Niceby Sejvej 12");
            Ordre ordre1 = new Ordre(1, pizza1, customer1);
            Ordre ordre2 = new Ordre(2, pizza2, customer2);
            Ordre ordre3 = new Ordre(3, pizza3, customer3);
            #endregion

            Console.WriteLine("_______________________________Adding Customers________________________________");
            #region Adding Customers
            CustomerFile.AddCustomers(customer1);
            CustomerFile.AddCustomers(customer2);
            CustomerFile.AddCustomers(customer3);
            CustomerFile.AddCustomers(customer4);
            #endregion
            Console.WriteLine();
            Console.WriteLine("_______________________________Removing Customers______________________________");
            #region Remove Customers
            CustomerFile.RemoveCustomers(customer1);
            #endregion
            Console.WriteLine();
            Console.WriteLine("_______________________________Finding Customers_______________________________");
            #region Find Customers By Id/Name
            CustomerFile.ReadCustomersById(3);
            CustomerFile.ReadCustomersByName("Karen");
            #endregion
            Console.WriteLine();
            Console.WriteLine("_______________________________Removing customers with ID______________________");
            #region Remove Customer By Id
            CustomerFile.RemoveCustomersById(3);
            #endregion
            Console.WriteLine();
            Console.WriteLine("_______________________________Updating Customers______________________________");
            #region Update Customer
            CustomerFile.UpdateCustomer(4, customer4);
            customer4.PhoneNo = "59372592";
            #endregion



            #region All Customers cw
            Console.WriteLine();
            Console.WriteLine("ALL CUSTOMERS:");
            Console.WriteLine("======================");
            #endregion
            //TO FIND ALL CUSTOMERS IN LIST
            CustomerFile.PrintMenu();
            //foreach (Customer customers in CustomerFile.GetCustomers())
            //{
            //    Console.WriteLine(customers);
            //    Console.WriteLine();
            //}
            Console.WriteLine();


            PizzaMenu pizzaMenu = new PizzaMenu();
            Console.WriteLine();
            Console.WriteLine("_______________________________Adding Pizzas___________________________________");
            #region Adding Pizzas
            PizzaMenu.AddPizza(pizza1);
            PizzaMenu.AddPizza(pizza2);
            PizzaMenu.AddPizza(pizza3);
            PizzaMenu.AddPizza(pizza4);
            #endregion
            Console.WriteLine();
            Console.WriteLine("_______________________________Removing Pizzas_________________________________");
            #region Remove Pizzas By Id
            PizzaMenu.RemovePizzaById(1);
            #endregion
            Console.WriteLine();
            Console.WriteLine("_______________________________Finding Pizzas__________________________________");
            #region Finding Pizzas By Id
            PizzaMenu.GetPizzaById(4);
            #endregion
            Console.WriteLine();
            Console.WriteLine("_______________________________Updating Pizzas_________________________________");
            #region Update Pizza (Name, Price)
            PizzaMenu.UpdatePizza(3, "MonsterPizzaXXL", 250);
            #endregion
            Console.WriteLine();

            //TO FIND ALL PIZZAS IN DICTIONARY
            Console.WriteLine("ALL PIZZAS");
            Console.WriteLine("======================");
            PizzaMenu.PrintMenu();
            


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("_______________________________Show Orders__________________________________");
            Console.WriteLine(ordre1);
            Console.WriteLine(ordre2);
            Console.WriteLine(ordre3);

        }
    }
}