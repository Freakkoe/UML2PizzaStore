﻿public class Customer
{
    public static int nextId = 1;
    public Customer()
    {
        Id = nextId++;
    }
    public Customer(string name, string email, string phoneNo, string address)
    {
        Id = nextId++;
        Name = name;
        Email = email;
        PhoneNo = phoneNo;
        Address = address;
    }
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string PhoneNo { get; set; }
    public string Address { get; set; }

    public override string ToString()
    {
        return $"{nameof(Id)}={Id.ToString()}, {nameof(Name)}={Name}, {nameof(Email)}={Email}, {nameof(PhoneNo)}={PhoneNo}, {nameof(Address)}={Address}";
    }
}