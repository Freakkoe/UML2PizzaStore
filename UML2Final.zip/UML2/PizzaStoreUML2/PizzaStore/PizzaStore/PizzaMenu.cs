﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore
{
    internal class PizzaMenu
    {
        public static Dictionary<int, pizza> PizzaDictionary = new Dictionary<int, pizza>();

        public static void AddPizza(pizza pizza)
        {
            if (!PizzaDictionary.ContainsKey(pizza.Id))
                Console.WriteLine($"Pizza added with Id={pizza.Id}");
                PizzaDictionary.Add(pizza.Id, pizza);
        }
        public static bool RemovePizzaById(int pizzaId)
        {
            if (PizzaDictionary.ContainsKey(pizzaId))
            {
                Console.WriteLine($"Removed pizza with {PizzaDictionary[pizzaId]}");
                return PizzaDictionary.Remove(pizzaId);

            }
            Console.WriteLine("No Pizzas Removed");
            return false;
        }
        public static pizza GetPizzaById(int id)
        {
            if (!PizzaDictionary.ContainsKey(id))
            {
                Console.WriteLine("No pizza found with Id");
                
            }
            else
            {
                Console.WriteLine($"Pizza found with id={PizzaDictionary[id]}");
                
            }
            return null;

        }

        public static void UpdatePizza(int id, string NewName, int NewPrice)
        {
            PizzaDictionary[id].Price = NewPrice;
            PizzaDictionary[id].NamePizza = NewName;
            Console.WriteLine($"Pizza Updated {PizzaDictionary[id]}");
        }

        #region Search pizza??
        //public static pizza SearchPizza(int Price)
        //{
        //    if (!PizzaDictionary.ContainsKey(Price))
        //    {
        //        Console.WriteLine("No pizza found with Price");

        //    }
        //    else
        //    {
        //        Console.WriteLine($"Pizza found with price={PizzaDictionary[Price]}");

        //    }

        //    return null;
        //}
        #endregion


        public static void PrintMenu()
        {
            foreach (var pizza in PizzaDictionary)
            {
                Console.WriteLine(pizza);
            }
        }


      
         
    }
}
