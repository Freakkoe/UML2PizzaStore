﻿public class pizza
{
    public static int nextId = 1;

    public pizza()
    {
        Id = nextId++;
    }
        
    public pizza(string namePizza, int price)
    {
        Id = nextId++;
        NamePizza = namePizza;
        Price = price;
    }

    public int Id { get; set; }
    public string NamePizza { get; set; }
    public int Price { get; set; }

    public override string ToString()
    {
        return $"{nameof(Id)}={Id.ToString()}, {nameof(NamePizza)}={NamePizza}, {nameof(Price)}={Price.ToString()}";
    }
}
