﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore
{
    public class CustomerFile
    {
        private static List<Customer> CustomerList = new List<Customer>();

        public static void AddCustomers(Customer customers)
        {
            Console.WriteLine($"Customer Added with ID={customers.Id}");
            CustomerList.Add(customers);
        }

        public static void AddCustomers(string name, string email, string adresse, string phoneNo)
        {
            CustomerList.Add(new Customer(name, email, adresse, phoneNo));
        }


        public static Customer RemoveCustomers(Customer customers)
        {
            CustomerList.Remove(customers);
            Console.WriteLine($"removed {customers}");
            return customers;
        }
         
        public static Customer RemoveCustomersById(int Id)
        {
            foreach (Customer customers in CustomerList)
            {
                if (customers.Id == Id)
                {
                    CustomerFile.RemoveCustomers(customers);
                    return customers;
                }
            }
            Console.WriteLine("nothing is removed");
            return null;
        }

        public static Customer ReadCustomersById(int id)
        {
            foreach (Customer customers in CustomerList)
            {
                if (customers.Id == id)
                {
                    Console.WriteLine($"Customer Found {customers}");
                    return customers;
                }
            }   
            Console.WriteLine("No Id found");
            return null;
        }

        public static Customer ReadCustomersByName(string name)
        {
            foreach (Customer customers in CustomerList)
            {
                if (customers.Name == name)
                {
                    Console.WriteLine($"Customer Found {customers}");
                    return customers;
                }
            }
            Console.WriteLine("No Id found");
            return null;
        }

        public static void UpdateCustomer(int id, Customer customerU)
        {
            foreach (Customer customer in CustomerList)
            {
                if (customer.Id == id)
                {
                    customer.Id = id;
                    customer.Address = customerU.Address;
                    customer.Email = customerU.Email;
                    customer.Name = customerU.Name;
                    customer.PhoneNo = customerU.PhoneNo;
                    Console.WriteLine($"{customer}");
                }
            }
        }


        public static List<Customer> GetCustomers()
        {
            return CustomerList;
        }

        public static void PrintMenu()
        {
            foreach (var customer in CustomerList)
            {
                Console.WriteLine(customer);
            }
        }

    }
}
